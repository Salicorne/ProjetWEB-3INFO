package fr.insa.rennes.web.model;

public class TestPlayer {
	// Unit tests that test the methods of Player
}
