package fr.insa.rennes.web;

public class Main {
	public static void main(String[] args) {
	}
}
